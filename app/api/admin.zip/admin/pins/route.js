import { NextResponse } from "next/server"
import connectToDatabase from "@/lib/db"
import PinCode from "@/lib/models/pinCode"
import { authorizeRequest } from "@/lib/utils/auth-server"
import { validateRequest, pinCreationSchema } from "@/lib/utils/validation"
import { generateUniquePin } from "@/lib/utils/pinGenerator"
import logger from "@/lib/utils/logger-server"

// GET all pins
export async function GET(request) {
  try {
    await connectToDatabase()

    // Authenticate and authorize user
    const authResult = await authorizeRequest(["admin", "super-admin"])(request)
    if (authResult.error) {
      return NextResponse.json({ status: "error", message: authResult.message }, { status: 401 })
    }

    const pins = await PinCode.find().sort({ createdAt: -1 })

    return NextResponse.json({ pins })
  } catch (error) {
    logger.error("Error fetching pins:", error)
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}

// POST generate new pins
export async function POST(request) {
  try {
    await connectToDatabase()

    // Authenticate and authorize user
    const authResult = await authorizeRequest(["admin", "super-admin"])(request)
    if (authResult.error) {
      return NextResponse.json({ status: "error", message: authResult.message }, { status: 401 })
    }

    const body = await request.json()

    // Validate request
    const validation = await validateRequest(pinCreationSchema, body)
    if (!validation.success) {
      return NextResponse.json(validation.error, { status: 400 })
    }

    const { count = 10, prefix = "" } = body

    // Generate PINs
    const pins = []
    for (let i = 0; i < count; i++) {
      const code = await generateUniquePin(prefix)
      pins.push({
        code,
        used: false,
        createdAt: new Date(),
        createdBy: authResult.user._id,
      })
    }

    // Save to database
    await PinCode.insertMany(pins)

    logger.info(`${count} PIN baru dibuat oleh ${authResult.user.username}`)

    return NextResponse.json({
      success: true,
      count,
      message: `Berhasil generate ${count} PIN baru`,
    })
  } catch (error) {
    logger.error("Error generating pins:", error)
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}
