import { NextResponse } from "next/server"
import connectToDatabase from "@/lib/db"
import PinCode from "@/lib/models/pinCode"
import { authorizeRequest } from "@/lib/utils/auth-server"
import logger from "@/lib/utils/logger-server"

export async function DELETE(request, { params }) {
  try {
    await connectToDatabase()

    // Autentikasi
    const authResult = await authorizeRequest(["admin", "super-admin"])(request)
    if (authResult.error) {
      return NextResponse.json({ error: authResult.message }, { status: 401 })
    }

    const pinId = params.id

    // Cari PIN
    const pin = await PinCode.findById(pinId)

    if (!pin) {
      return NextResponse.json({ error: "PIN tidak ditemukan" }, { status: 404 })
    }

    if (pin.used) {
      return NextResponse.json({ error: "PIN sudah digunakan dan tidak bisa dihapus" }, { status: 400 })
    }

    await PinCode.findByIdAndDelete(pinId)

    logger.info(`PIN ${pin.code} dihapus oleh ${authResult.user.username}`)

    return NextResponse.json({ message: "PIN berhasil dihapus" })
  } catch (error) {
    logger.error("Gagal menghapus PIN:", error)
    return NextResponse.json({ error: "Terjadi kesalahan saat menghapus PIN" }, { status: 500 })
  }
}
