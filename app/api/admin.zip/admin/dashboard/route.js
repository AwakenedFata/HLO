import { NextResponse } from "next/server"
import connectToDatabase from "@/lib/db"
import PinCode from "@/lib/models/pinCode"
import logger from "@/lib/utils/logger-server"
import { authorize } from "@/lib/middleware/authMiddleware"

export async function GET(request) {
  try {
    await connectToDatabase()

    // Authenticate and authorize user
    const authResult = await authorize("admin", "super-admin")(request)
    if (authResult.error) {
      return NextResponse.json({ status: "error", message: authResult.message }, { status: authResult.status })
    }

    // Hitung total pin
    const totalPins = await PinCode.countDocuments()

    // Hitung pin aktif
    const activePins = await PinCode.countDocuments({
      isActive: true,
      expiresAt: { $gt: new Date() },
    })

    // Hitung pin yang sudah digunakan
    const usedPins = await PinCode.countDocuments({
      "usedBy.0": { $exists: true },
    })

    // Dapatkan pin yang dibuat dalam 7 hari terakhir
    const last7Days = new Date()
    last7Days.setDate(last7Days.getDate() - 7)

    const recentPins = await PinCode.find({
      createdAt: { $gte: last7Days },
    })
      .sort({ createdAt: -1 })
      .limit(10)

    // Dapatkan penggunaan pin terbaru
    const recentUsage = await PinCode.aggregate([
      { $unwind: "$usedBy" },
      { $sort: { "usedBy.usedAt": -1 } },
      { $limit: 10 },
      {
        $project: {
          code: 1,
          userId: "$usedBy.userId",
          usedAt: "$usedBy.usedAt",
          deviceInfo: "$usedBy.deviceInfo",
          ipAddress: "$usedBy.ipAddress",
        },
      },
    ])

    logger.info(`Statistik dashboard diakses oleh ${authResult.user.username}`)

    return NextResponse.json({
      status: "success",
      data: {
        stats: {
          totalPins,
          activePins,
          usedPins,
          expiredPins,
        },
        recentPins,
        recentUsage,
      },
    })
  } catch (err) {
    logger.error(`Error getting dashboard stats: ${err.message}`)
    return NextResponse.json(
      { status: "error", message: "Terjadi kesalahan saat mengambil statistik dashboard" },
      { status: 500 },
    )
  }
}
