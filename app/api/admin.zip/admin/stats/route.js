import { NextResponse } from "next/server"
import connectToDatabase from "@/lib/db"
import PinCode from "@/lib/models/pinCode"
import { authorizeRequest } from "@/lib/utils/auth-server"
import logger from "@/lib/utils/logger-server"

export async function GET(request) {
  try {
    await connectToDatabase()

    // Authenticate and authorize user
    const authResult = await authorizeRequest(["admin", "super-admin"])(request)
    if (authResult.error) {
      return NextResponse.json({ status: "error", message: authResult.message }, { status: 401 })
    }

    const allPins = await PinCode.find()
    const total = allPins.length
    const used = allPins.filter((pin) => pin.used).length
    const unused = total - used

    // Group pins by prefix
    const prefixes = {}

    allPins.forEach((pin) => {
      // Extract prefix (3 characters) or use "NO_PREFIX"
      const prefix = pin.code.substring(0, 3) || "NO_PREFIX"
      if (!prefixes[prefix]) {
        prefixes[prefix] = 0
      }
      prefixes[prefix]++
    })

    // Convert to array for chart
    const batches = Object.keys(prefixes).map((prefix, index) => ({
      id: index + 1,
      name: prefix,
      count: prefixes[prefix],
    }))

    logger.info(`Statistik diakses oleh ${authResult.user.username}`)

    return NextResponse.json({
      total,
      used,
      unused,
      batches,
    })
  } catch (error) {
    logger.error("Error fetching stats:", error)
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}
