import { NextResponse } from "next/server"
import { authenticateRequest } from "@/lib/utils/auth-server"
import logger from "@/lib/utils/logger-server"

export async function GET(request) {
  try {
    // Authenticate user
    const authResult = await authenticateRequest(request)
    if (authResult.error) {
      return NextResponse.json({ status: "error", message: authResult.message }, { status: 401 })
    }

    // If middleware passes, token is valid
    return NextResponse.json({
      status: "success",
      admin: {
        id: authResult.user._id,
        username: authResult.user.username,
        role: authResult.user.role,
      },
    })
  } catch (error) {
    logger.error(`Token verification error: ${error.message}`)
    return NextResponse.json({ status: "error", message: "Token tidak valid" }, { status: 401 })
  }
}
